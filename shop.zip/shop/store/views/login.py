from django.shortcuts import render , redirect
from store.models.product import Products
from store.models.customer import Customer
from django.contrib.auth.hashers import  check_password
from django.views import View


class Login(View):

    def get(self,request):
        return render(request, 'login.html')

    def post(self,request):
        email = request.POST.get('email')
        password = request.POST.get('password')
        customer = Customer.geteC_email(email)
        message = None
        if customer:
            check = check_password(password, customer.password)
            if check:
                request.session['customer']=customer.id

                return redirect('homepage')
            else:
                message = 'Email or password invalid'
        else:
            message = 'Email or password in valid'
            print(email,password)
        return render(request, 'login.html', {'error': message})


def logout(request):
    request.session.clear()
    return  redirect('login')