from django.contrib import admin
from django.urls import path, include
from .views import home, login, signup
from  .views.cart import Cart
from .views.go import go , Checkout
from .views.ordersview import Ordersview
from .views.login import logout


urlpatterns = [
    path('', home.Index.as_view(), name='homepage'),
    path('signup', signup.Signup.as_view(), name='signup'),
    path('login', login.Login.as_view(), name='login'),
    path('login', login.Login.as_view(), name='login'),
    path('logout', logout, name='logout'),
    path('cart', Cart.as_view(), name='cart'),
    path('go', go, name='go'),
    path('check-out', Checkout.as_view(), name='go'),
    path('orders', Ordersview.as_view(), name='orders'),



]
