from django.contrib import admin

# Register your models here.
from .models.product import Products
from  .models.category import Category
from.models.customer import Customer
from .models.orders import Orders


admin.site.register(Products)
admin.site.register(Category)
admin.site.register(Customer)
admin.site.register(Orders)




